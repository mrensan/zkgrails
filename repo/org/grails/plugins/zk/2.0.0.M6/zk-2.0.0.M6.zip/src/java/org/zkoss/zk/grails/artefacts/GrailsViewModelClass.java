/* GrailsViewModelClass.java

Copyright (C) 2011 Chanwit Kaewkasi

*/
package org.zkoss.zk.grails.artefacts;

public interface GrailsViewModelClass {

}
